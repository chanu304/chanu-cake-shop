/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author kavindu
 */
public class DBConnection {
    
    private static final String URL = "jdbc:mysql://localhost:3306/chanucakeshop";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static Connection connection = null;
    
    // Establishes the database connection and returns a Statement object
    public static Statement getStatementConnection() {
        try {
            // Establish the connection
            String url = "jdbc:mysql://localhost:3306/chanucakeshop";
            Connection conn;
            conn = DriverManager.getConnection(url, "root", "");
            // Create the statement
            return conn.createStatement();
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, null, ex);
            // Handle or log the exception as needed 
            return null;
        }
    }

    public static void closeCon() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/chanucakeshop", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            return null;
        } 

}
}
